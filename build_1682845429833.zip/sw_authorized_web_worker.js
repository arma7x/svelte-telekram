importScripts('/js/polyfill.min.js');
importScripts('/js/telegram.js');
importScripts('/js/idb.js');
importScripts('/build/authorizedWebWorker.js');
